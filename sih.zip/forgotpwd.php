<?php
require "header.php";
?>

<html>
    <head>
        <title>Forgot Password</title>
    </head>

    <body>
        <form action="ulogin.php" method="post">
            <input type="text" name="emailReq" placeholder="Enter Email">
            <button type="submit" name="login-submit">Request</button>
        </form>

    </body>
</html>

