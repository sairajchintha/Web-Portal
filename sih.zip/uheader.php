<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>AICTE</title>

<link href="css/style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="engine/styleSlider.css"/>

<link rel="stylesheet" href="css/styles.css">

<script type="text/javascript" src="engine/jquery.js"></script>



<link href="css/style-popup.css" type="text/css" rel="stylesheet" />



    <style type="text/css">

        .style1

        {

            font-size: medium;

        }

		

         .style2

        {

            float: center;

            line-height: 50px;

            text-align: center;

            color: #FFFFFF;

            font-weight: 700;

			background : transparent;

        }

		.style3

		{

			background : transparent;

		}

		img div{

		height:160px;

		width:1250px;

		 }

    </style>



</head>



<body>

<div id="wrapper">

<div class="wrapper_content">

<div id="top-head">

<div img src="images/background1.jpg">

</div>

</div>



<div id='cssmenu'>

<ul>

<li><a href="index.html" class="active"><img src="images/home.png" alt="Mountain View" style="width:25px;height:25px;"></a>



	  </li>





      <li><a href="includes/logout.inc.php">Log Out</a></li>

<li><a href="ucontact_us.html">Contact us</a></li>

<li><a href="aboutus.html">About us</a></li>

<li><a href="faq.html">FAQ</a></li>

<li><a href="patent.html">Patents&Copyrights</a></li>

 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 

<marquee scrollamount="6" onmouseover="stop()" onmouseout="start()" style="color : orange; font-size : 20px; font-family : verdana;">

example sentences are to be displayed here incase nedded.sdgzzzz............<font color = "black">

</font><font color="blue">Innovate.........Implement..........Invent</font><font color="black"> in</font>

<font color="green">All India Council for Technical Education(AICTE) </font>

</marquee>

<div id="header">

<div id="wowslider-container1">

    <div class="ws_images"> 

    

    <a href="#"><img src="images/2.png" /> </a>

    <a href="#"><img src="images/1.png" /> </a>

	<a href="#"><img src="images/4.png" /> </a>

   </div>

  </div>

  <script type="text/javascript" src="engine/script.js"></script></div></div>



<div id="left">

<div class="left-box">

<div class="left-heading">Reference site<img src="images/border.png" style="margin-top:5px" /></div>

<div class="list">

<ul>



<li><a href="https://www.nic.in/"><p style="font-size:20px">Nic portal</p><br></span></a>

        </li>

        <li><a href="https://www.sih.gov.in/"><p style="font-size:20px">SIH Site</p><br></span></a>

        <li><a href="https://mhrd.gov.in/"><p style="font-size:20px">MHRD portal</p></span></a>

        </ul></div>

        </div>



<div class="left-box">

<div class="left-heading">SUBMIT<img src="images/border.png" style="margin-top:5px" /></div>

<div class="list">

<ul>

<li><a href="IdeaSubmit.php"><p style="font-size:20px">Idea</p><br></span></a>

</li>

<li><a href="IdeaSubmit.php"><p style="font-size:20px">Best Practice</p><br></span></a></li>

</ul>

</div>

</div>





<div class="left-box">

<div class="left-heading">IDEA<img src="images/border.png" style="margin-top:5px" /></div>

<div class="list">

<ul>

<li><a href="ideastatus.user.php?x=p"><p style="font-size:20px">Pending Ideas</p><br></span></a>

<li><a href="http://princepatel.ga/ideastatus.user.php?x=h"><p style="font-size:20px">History</p><br></span></a>

</li>

</ul>

</div>

</div>

<div class="left-box">

<div class="left-heading">SUPPORTED BY<img src="images/border.png" style="margin-top:5px" /></div>

<div class="list">

<img src="aicte.jpg" height="150px" width="237px" style="margin-left:10px; margin-top:10px; border:1px solid #000" />

<p style="text-align:center"><a href="http://www.aicte-india.org/" target="_blank"><b>

   AICTE,  Delhi</b></a><br />



NewDelhi, Delhi, India<br/>

Website: http://www.aicte.org/

   

</p>

<div id="read-more"><a href="aicte-india.org">Read more</a></div></div>

</div>

<div class="left-box">

<div class="left-heading">Hit Counter<img src="images/border.png" style="margin-top:5px" /></div>

<div class="list">

<ul>

<li><center><!-- Start of WebFreeCounter Code -->

    <a href="index.html" target="_blank"><img src="https://www.webfreecounter.com/hit.php?id=zmmoxxk&nd=6&style=5" border="0" alt="web counter"></a>

    <!-- End of WebFreeCounter Code -->

</center>

</li>

</ul>

</div>

</div>



</div>

