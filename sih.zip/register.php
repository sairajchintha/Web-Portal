<?php
ob_start();
?>


<html>
<head>
<meta name="google-signin-client_id" content="250297989974-cfklke3vhq0k9ch23b6ltqev8c2uol7s.apps.googleusercontent.com">
<script src="https://apis.google.com/js/platform.js" async defer></script>
<meta name="google-signin-scope" content="profile email">
    <title>Register Page</title>

    
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine/styleSlider.css"/>
<link rel="stylesheet" href="css/styles.css">
<script type="text/javascript" src="engine/jquery.js"></script>

<link href="css/style-popup.css" type="text/css" rel="stylesheet" />

     
    <style type="text/css">
        .style1
        {
            font-size: medium;
        }
		
         .style2
        {
            float: center;
            line-height: 50px;
            text-align: center;
            color: #FFFFFF;
            font-weight: 700;
			background : transparent;
        }
		.style3
		{
			background : transparent;
		}
    
input[type=text],select,input[type=email],input[type=tel],textarea,input[type=date], input[type=password] {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  box-sizing: border-box;}


button {
  background-color:black;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 20%;
}

button:hover {
  background-color:green;
}
#saiko{
    position:relative;
    top:11%;
    bottom:1%;
left:50px;
height:100%;
}
.address{
    position:absolute;
    top:650px;
    left:475px;
}
body{
    margin-top:40px;
    
    
}
.image{
    position:absolute;
    top:450px;
    left:90px;
}
    .register{
        position:absolute;
        top:200px;
        left:0px;
    } 
    </style>
</head>
<body>
<div class="test">


<body>
<div id="wrapper">
<div class="wrapper_content">
<div id="top-head">
<div img src="images/background1.jpg">
</div>
</div>

<div id='cssmenu'>
<ul>
<li><a href="index.html" class="active"><img src="images/home.png" alt="Mountain View" style="width:25px;height:25px;"></a>

  </li>


<li><a href="#">LOGIN</a>
<ul>
     <li class='has-sub'><a href='ulogin.php'><span>User Login</span></a>
     </li>
     <li class='has-sub'><a href='alogin.php'><span>Admin Login</span></a>
     </li>

  </ul>
</li>
<li><a href="register.php">Register</a></li>
<li><a href="contact_us.html">Contact us</a></li>
<li><a href="aboutus.html">About us</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="patent.html">Patents&Copyrights</a></li>


</ul>
</div>
<!-- Subtitle -->
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<marquee scrollamount="6" onmouseover="stop()" onmouseout="start()" style="color : orange; font-size : 20px; font-family : verdana;">
example sentences are to be displayed here incase nedded.sdgzzzz............<font color = "black">
</font><font color="blue">Innovate.........Implement..........Invent</font><font color="black"> in</font>
<font color="green">All India Council for Technical Education(AICTE) </font>
</marquee>
<div id="header">
<div id="wowslider-container1">
<div class="ws_images"> 

<a href="#"><img src="images/2.png" /> </a>
<a href="#"><img src="images/1.png" /> </a>
<a href="#"><img src="images/4.png" /> </a>
</div>
</div>
<script type="text/javascript" src="engine/script.js"></script></div></div>

<div id="left">
<div class="left-box">
<div class="left-heading">Side bar<img src="images/border.png" style="margin-top:5px" /></div>
<div class="list">
<ul>

<li><a href="https://www.nic.in/"><p style="font-size:20px">Nic portal</p><br></span></a>
        </li>
        <li><a href="https://www.sih.gov.in/"><p style="font-size:20px">SIH Site</p><br></span></a>
        <li><a href="https://mhrd.gov.in/"><p style="font-size:20px">MHRD portal</p></span></a>
        </ul></div>
        </div>

<div class="left-box">
<div class="left-heading">pending<img src="images/border.png" style="margin-top:5px" /></div>
<div class="list">
<ul>
<li><a href="principal.html"><p style="font-size:20px">Test Link1</p><br></span></a>
</li>
</ul>
</div>
</div>


<div class="left-box">
<div class="left-heading">Hit Counter<img src="images/border.png" style="margin-top:5px" /></div>
<div class="list">
<ul>
<li><center><!-- Start of WebFreeCounter Code -->
    <a href="index.html" target="_blank"><img src="https://www.webfreecounter.com/hit.php?id=zmmoxxk&nd=6&style=5" border="0" alt="web counter"></a>
    <!-- End of WebFreeCounter Code -->
</center>
<ul>
</li>
</ul>
</div>
</div>
<div class="left-box">
<div class="left-heading">SUPPORTED BY<img src="images/border.png" style="margin-top:5px" /></div>
<div class="list">
<img src="aicte.jpg" height="150px" width="237px" style="margin-left:10px; margin-top:10px; border:1px solid #000" />
<p style="text-align:center"><a href="http://www.aicte-india.org/" target="_blank"><b>
AICTE,  Delhi</b></a><br />

NewDelhi, Delhi, India<br/>
Website: http://www.aicte.org/

</p>
<div id="read-more"><a href="aicte-india.org">Read more</a></div></div>
</div>
<div class="left-box">
<div class="left-heading">Change Language<img src="images/border.png" style="margin-top:5px" /></div>
<div class="list">
<ul>
<li><center>


<div id="google_translate_element"></div>
<script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
    </script>
    
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script><br />
</center>
</li>
</ul>
</div>
</div>

</div>

<div align="center" > 
<h1 style="color:green;">Registration Form</h1>
<form style="position:relative;
top:50px; "  action="register.php" method="post">
  
    <input type="text" name="fname" id="fid" placeholder="Firstname" required>
  
    <input type="text" name="lname" id="lid" placeholder="Lastname" required><br>
  
    <input type="text" name="uid" id="uid" placeholder="username" required>
  
    <input type="email" name="mail"   placeholder="email" required><br>
    
 
    <input type="text" name="course" placeholder="Course eg:BE,B.tech,B.com etc">
    <input type="text" name="inst" placeholder="Educational Institution"><br>
    <select class="select" name="year">
    <option value="select">Select year</option>
    <option value="1">I</option>
    <option value="2">II</option>
    <option value="3">III</option>
    <option value="4">IV</option>
    </select>
    <input type="Date" class="select" placeholder="Date of birth" name="dob" required><br>
    
    
    <input type="password" name="pwd" id="pwd" placeholder="Password" required>
    <input type="password" name="pwd-repeat" id="pwd-repeat" placeholder="Confirm Password" required><br>
    
    <input type="tel" name="mobnum" maxlength="10" placeholder="Mobile number" required> <br>
    <textarea name="add" rows="5" cols="20"   placeholder="enter your address" required></textarea><br>
    
    <label for="sex"><b>SEX:</b></label>
       Male:<input type="radio" name="sex" value="male">
       Female:<input type="radio" name="sex" value="female">
       Other:<input type="radio" name="sex" value="other">
    <br><button type="submit" name="signup-submit">Sign-up</button>
    <div class="g-signin2" data-onsuccess="onSignIn"></div>
</form></div>

<div id="fr-main"><font color="white">
<div class="copy-right">Copyright &copy; - SIH-2019
</div></div>
</body>
</html>


<!--Signup Script!-->
<?php

require "includes/udbh.inc.php";

//verifying if signup button is clicked
if(isset($_POST['signup-submit'])){
    session_start();
    //taking input values from signup form

   //login information
   $username=$_POST['uid'];
   $email=$_POST['mail'];
   $password=$_POST['pwd'];
   $passwordRepeat=$_POST['pwd-repeat'];
   
  //personal inofmation
  $firstname=$_POST['fname'];
  $lastname=$_POST['lname'];
  $course=$_POST['course'];
  $year=$_POST['year'];
  $einstutuion=$_POST['inst'];
  $mobileno=$_POST['mobnum'];
  $address=$_POST['add'];
  $sex=$_POST['sex'];
  $bdate=$_POST['dob'];

 
 //validations--------------------------------

    //empty field validation
    if(empty($username) || empty($email) || empty($password) || empty($passwordRepeat) || empty($firstname) || 
    empty($lastname) || empty($course) || empty($einstutuion) || empty($address) || empty($mobileno) || empty($bdate) || empty($sex)){
        echo '<script language="javascript">';
        echo 'alert("Please Fill all the fields")';  //not showing an alert box.
        echo '</script>';
        exit();

    }

    //email validation and username validation
    else if(!filter_var($email,FILTER_VALIDATE_EMAIL) && (!preg_match("/^[a-zA-Z0-9]*$/", $username))) {
        echo '<script language="javascript">';
    echo 'alert("Username/email is invalid")';  //not showing an alert box.
    echo '</script>';

        exit();
    }
    //email validation
    else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo '<script language="javascript">';
        echo 'alert("Please enter valid Email")';  //not showing an alert box.
        echo '</script>';
        exit();
    }
    
    //username validation
    else if(!preg_match("/^[a-zA-Z0-9]*$/", $username)){
        echo '<script language="javascript">';
    echo 'alert("Please enter valid username")';  //not showing an alert box.
    echo '</script>';
        exit();
    }
    //password and confirm password validation
    else if($password !== $passwordRepeat){
        echo '<script language="javascript">';
    echo 'alert("Passwords does not match")';  
    echo '</script>';
        exit();
    }

    //password size validation
    else if(strlen($password)<8){
        echo '<script language="javascript">';
    echo 'alert("minimum 8 characters are required for password")'; 
    echo '</script>';
        exit();
      }


    //year droplist validation
    else if($year=='none'){
        echo '<script language="javascript">';
    echo 'alert("select year please")';  
    echo '</script>';
        exit();
    }

    //mobile no digit validation
    else if(!preg_match("/^[0-9]*$/", $mobileno)){
        echo '<script language="javascript">';
    echo 'alert("enter valid mobile.No")';  
    echo '</script>';
        exit();
    }

    //mobile no size validation
    else if(strlen($mobileno)!=10){
        echo '<script language="javascript">';
    echo 'alert("enter valid mobile.No")'; 
    echo '</script>';
        exit();
    }


 
    
    //password hashing
    $hashPwd=password_hash($password, PASSWORD_DEFAULT);
    
    //activation code generating
    $code=rand(10,100);
    $acode=password_hash($code, PASSWORD_DEFAULT);
     //sql querry with injection
   $sql="insert into `logindetail`(userName , email , pass , acode) values('"
   .mysqli_real_escape_string($conn,$username) ."','"
   .mysqli_real_escape_string($conn,$email). "','"
   .mysqli_real_escape_string($conn, $hashPwd). "','"
   .mysqli_real_escape_string($conn, $acode).'\')';
  
  
  $sql2="insert into `personaldetail`(Username,FirstName,lastname,course,year,education,mobileno,address,sex,dob) values('"
  .mysqli_real_escape_string($conn,$username)."','"
  .mysqli_real_escape_string($conn,$firstname)."','"
  .mysqli_real_escape_string($conn,$lastname)."','"
  .mysqli_real_escape_string($conn,$course)."','"
  .mysqli_real_escape_string($conn,$year)."','"
  .mysqli_real_escape_string($conn,$einstutuion)."','"
  .mysqli_real_escape_string($conn,$mobileno)."','"
  .mysqli_real_escape_string($conn,$address)."','"
  .mysqli_real_escape_string($conn,$sex)."','"
  .mysqli_real_escape_string($conn,$bdate).'\')';
    

    //verifying if user/email already exists in database
    $u="select * from logindetail where username = '$username'";
$e="select * from logindetail where email = '$email'";
$resultuser=mysqli_query($conn,$u);
$resultemail=mysqli_query($conn,$e);
$num2=mysqli_num_rows($resultemail);
$num1=mysqli_num_rows($resultuser);
if($num1==1 || $num2==1){
    echo '<script language="javascript">';
    echo 'alert("UserName or Email Already exists")';  
    echo '</script>';
    exit();

} else{


    $to_email = $email;

    $subject = 'Account Activation Link';

    $message = 'Want to submit your innovative ideas to our portal? <br> You are just one step away from logging into our website! <br> Click the link below to verify your email and submit your ideas and do wonders! <br> : http://princepatel.ga/activate.php?code='.$acode;

    $headers = 'From: sparks@princepatel.ga	';

    mail($to_email,$subject,$message,$headers);


    header('location:ulogin.php?activation=sent');
    $_SESSION['user']=$username;

    //submitting login details to database
    mysqli_query($conn,$sql);

    //submitting personal details to database
    mysqli_query($conn,$sql2);

    //closing connection
    mysqli_close($conn);
    exit();
    }

    
}

require 'footer.html';
    ?>
