<?php require "uhome.php" ?>

<?php
echo $_GET['x'];
?>