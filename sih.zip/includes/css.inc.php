<?php 
  $minCss=' <link href="../css/login.css" rel="stylesheet">';
  echo $minCss;
?>